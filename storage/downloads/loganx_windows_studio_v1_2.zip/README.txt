LOGANX Desktop Studio for Windows
Version 1.2.0

Thank you for downloading LOGANX Desktop Studio!
For documentation and guides, visit https://loganx.io
